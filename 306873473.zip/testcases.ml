open A2

let %test "eval_6" = 
  try let _ = eval ( Add (ConstV [1.2] , ConstV[1.2;3.4])) in false with Wrong _ -> true | _ -> false
let %test "eval_5" = 
  try let _  =  type_of(ConstV []) in false with Wrong _ -> true | _ -> false
let%test "eval_4" =
  try let _ = eval (Angle (ConstV [0.0; 0.0], ConstV [1.0; 0.0])) in false with Wrong _ -> true
let%test "eval_3" =
  try let _ = eval (Inv (Cond (ConstS 1.0, ConstS 2.0, ConstS 3.0))) in false with Wrong _ -> true | _ -> false
let%test "eval_2" =
  try let _ = eval (Cond (T,  ConstS 34234.0 ,Add ( ConstV [245.0], ConstS 2423.0))) in false with Wrong _ -> true | _ -> false
let%test "eval_1" =
  try let _ = eval (Cond (F,  F ,ConstV [2324.0])) in false with Wrong _ -> true  | _ -> false 
let%test "eval_7" =
  try let _ = eval (Angle (ConstV [345.345], ConstS 24.234)) in false with Wrong _ -> true | _ -> false
let%test "eval_8" =
  try let _ = eval (Mag F) in false with Wrong _ -> true | _ -> false
let%test "eval_9" =
  try let _ = eval (ScalProd (ConstV [467.97], ConstV [57.554])) in false with Wrong _ -> true | _ -> false
let%test "eval_12" =
  try let _ = eval (DotProd (F, T)) in false with Wrong _ -> true | _ -> false  
let%test "eval_11" =
  try let _ = eval (DotProd (ConstS 98.343, ConstS 0.0 )) in false with Wrong _ -> true| _ -> false
let%test "eval_10" =
  try let _ = eval (DotProd (ConstV [445.32232;4.322; 232.232;323.23232], ConstV [34.532])) in false with Wrong _ -> true| _ -> false
let%test "eval_15" =
  try let _ = eval (Add (ConstV [43.23;32.22;232.232;34332.23;23.3], ConstV [2.323])) in false with Wrong _ -> true | _ -> false  
let%test "eval_14" =
  try let _ = eval (Add (ConstV [43.23;32.22;232.232;34332.23;23.3], ConstS 2.323)) in false with Wrong _ -> true | _ -> false
let%test "eval_13" =
  try let _ = eval (Add (ConstS 2432.2223, F)) in false with Wrong _ -> true | _ -> false
let%test "type_16" =
  try let _ = type_of (Cond (F, ConstS 23.33333,ConstV [2.21;232.22;2342.2;343.3;43.3;23.2] )) in false with Wrong _ -> true | _ -> false
let%test "type_17" =
  try let _ = type_of (Cond (ConstV [2.21;232.22;2342.2;343.3;43.3;23.2], T, F)) in false with Wrong _ -> true | _ -> false
let%test "type__20" =
  try let _ = type_of (Angle (ConstS 6.45, ConstV [3.2])) in false with Wrong _ -> true  | _ -> false
let%test "type_18" =
  try let _ = type_of (Angle (T, F)) in false with Wrong _ -> true  | _ -> false
let%test "type_19" =
  try let _ = type_of (Angle (ConstV [5.5;33.3], ConstS 3.3)) in false with Wrong _ -> true  | _ -> false
let%test "type_20" =
  try let _ = type_of (Mag T) in false with Wrong _ -> true | _ -> false
let%test "type_21" =
  try let _ = type_of (ScalProd (ConstV [7.776], ConstV [3.0;5.4;2.222;2222.2;6.66;8.8])) in false with Wrong _ -> true | _ ->false
let%test "type_22" =
  try let _ = type_of (ScalProd (ConstS 4.332, F)) in false with Wrong _ -> true | _ ->false
let%test "type_23" =
  try let _ = type_of (ScalProd (F, ConstS 3.3323)) in false with Wrong _ -> true | _ ->false
let%test "type_25" =
  try let _ = type_of (DotProd (ConstV [8.76;4.422], ConstV [234223.22])) in false with Wrong _ -> true | _ -> false
let%test "type_26" =
  try let _ = type_of (DotProd (ConstS 887.6, ConstS 5.3222)) in false with Wrong _ -> true | _ -> false
let%test "type_24" =
  try let _ = type_of (DotProd (F, F)) in false with Wrong _ -> true |  _ -> false
let%test "type_30" =
  try let _ = type_of (Add (ConstV[4.5;2.223] , ConstV [5.54])) in false with Wrong _ -> true | _ -> false   
let%test "type_29" =
  try let _ = type_of (Add (F , ConstV [5.54])) in false with Wrong _ -> true | _ -> false 
let%test "type_28" =
  try let _ = type_of (Add (ConstV [69.0], ConstS 69.0)) in false with Wrong _ -> true | _ -> false
let%test "type_27" =
  try let _ = type_of (Add (ConstS 7.655, F)) in false with Wrong _ -> true | _ -> false
let%test "eval_33" = eval (Cond (F, ConstS 45.0, ConstS 0.0)) = S 0.0
let%test "eval_34" = eval (Cond (T, ConstS 45.0, ConstS 0.0)) = S 45.0
let%test "eval_31" = eval (Cond (F, T, F)) = B false
let%test "eval_32" =
  match eval (Cond (T, ConstV [0.0;0.0], ConstV [3413.02;43123.023])) with V v -> v = [0.0;0.0] | _ -> false
let%test "eval_39" = eval (IsZero (ConstS 1e-8)) = B true
let%test "eval_40" = eval (IsZero T) = B false
let%test "eval_41" = eval (IsZero F) = B true
let%test "eval_35" = eval (IsZero (ConstV [1e-4])) = B false
let%test "eval_36" = eval (IsZero (ConstV [1e-9])) = B true
let%test "eval_38" = eval (IsZero (ConstS 0.1)) = B false
let%test "eval_37" = eval (IsZero (ConstV [0.0;0.0;0.0;0.0;0.0])) = B true
let%test "eval_42" =
  match eval (Angle (ConstV [5.0;0.0], ConstV [4.0;4.0])) with | S a -> md (a -. ( Float.pi /. 4.0)) < 1e-3 | _ -> false
let%test "eval_43" = eval (Mag (ConstV [5.0;12.0])) = S 13.0
let%test "eval_44" = eval (Mag (ConstS (-5.34))) = S 5.34
let%test "eval_45" = eval (DotProd (ConstV [1.0;2.0], ConstV [3.0;4.0])) = S 11.0
let%test "eval_49" = eval (ScalProd (ConstS 2.5, ConstS 2.0)) = S 5.0
let%test "eval_47" = eval (ScalProd (F, T)) = B false
let%test "eval_48" = eval (ScalProd (T, T)) = B true
let%test "eval_46" =
  match eval (ScalProd (ConstV [34.0;12.0], ConstS 10.0)) with | V v -> v = [340.0;120.0] | _ -> false
let%test "eval_51" = match eval (Inv (ConstV [12.3])) with| V v -> v = [-12.3] | _ -> false
let%test "eval_50" = eval (Inv T) = B false
let%test "eval_53" = eval (Add (F, F)) = B false
let%test "eval_52" = eval (Add (T, F)) = B true
let%test "eval_55" = match eval (Add (ConstV [0.0;67.0], ConstV [33.0;0.0])) with | V v -> v = [33.0;67.0] | _ -> false
let%test "eval_54" = eval (Add (ConstS 23.0, ConstS 2.0)) = S 25.0
